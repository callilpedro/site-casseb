function alterarCor() {
    const cor = document.getElementById('colorPicker').value;
    document.body.style.backgroundColor = cor;
}