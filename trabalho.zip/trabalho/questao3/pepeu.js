const usuarios = [
    { email: 'ale@cesupa.br', senha: '123123', site: 'https://www.cesupa.br' },
    { email: 'pedro@giroto.com', senha: '223344', site: 'https://www.detran.gov.br' },
    { email: 'isaac@java.com', senha: 'asdasd', site: 'https://www.idopterlabs.com' }
];

function verificarLogin() {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const erroMessage = document.getElementById('erroMessage');

    // Verificar se o email e senha estão corretos
    const usuario = usuarios.find(u => u.email === email && u.senha === senha);
    if (usuario) {
        window.location.href = usuario.site;
        return false; // Para evitar o envio do formulário
    } else {
        erroMessage.style.display = 'block';
        erroMessage.textContent = 'Email ou senha incorretos';
        return false;
    }
}